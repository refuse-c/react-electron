self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4e0356f519813ee4839bbf6973118825",
    "url": "./index.html"
  },
  {
    "revision": "d544ec4905fd63920303",
    "url": "./static/css/2.1f647b0f.chunk.css"
  },
  {
    "revision": "1dd11ab0f2c054cc1b09",
    "url": "./static/css/main.a6e27170.chunk.css"
  },
  {
    "revision": "d544ec4905fd63920303",
    "url": "./static/js/2.95976f19.chunk.js"
  },
  {
    "revision": "8ebb70227fec3b61ad3af3d99ebe8940",
    "url": "./static/js/2.95976f19.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1dd11ab0f2c054cc1b09",
    "url": "./static/js/main.7c2b79dd.chunk.js"
  },
  {
    "revision": "69e5917501884b2aab88",
    "url": "./static/js/runtime-main.6efe476c.js"
  },
  {
    "revision": "f107403e5207a7124e213e3265a69062",
    "url": "./static/media/0.f107403e.png"
  },
  {
    "revision": "51475e55fcb78b8382d2aa29c162c373",
    "url": "./static/media/1.51475e55.png"
  },
  {
    "revision": "ad2279626203ad4da6b5c8f59deb1d24",
    "url": "./static/media/2.ad227962.png"
  },
  {
    "revision": "35492cb9c95b95363180e70f6d39a3e9",
    "url": "./static/media/3.35492cb9.png"
  },
  {
    "revision": "7de3158e9d5af6c4925efbc57562b1c6",
    "url": "./static/media/4.7de3158e.png"
  },
  {
    "revision": "1e82c5a6fcc81bb4c455063f96f95d62",
    "url": "./static/media/6.1e82c5a6.jpg"
  },
  {
    "revision": "88363dd90b5d09e167ae740120d3f215",
    "url": "./static/media/apg.88363dd9.png"
  },
  {
    "revision": "dbded778dd28241e026646d53813ff25",
    "url": "./static/media/artist-top.dbded778.jpg"
  },
  {
    "revision": "6f86adef5912b305671feb1b4cf1b3d4",
    "url": "./static/media/text0.6f86adef.png"
  },
  {
    "revision": "4ea3e5933175f18496eaeb36615121fc",
    "url": "./static/media/text1.4ea3e593.png"
  },
  {
    "revision": "848f9125ebd6f5a378dfe6421ac76544",
    "url": "./static/media/text2.848f9125.png"
  },
  {
    "revision": "9c6a5dcaf1fd41f695e6bdd97f550797",
    "url": "./static/media/text3.9c6a5dca.png"
  },
  {
    "revision": "53a6c9449956dd02c676312766ed7773",
    "url": "./static/media/text4.53a6c944.png"
  }
]);